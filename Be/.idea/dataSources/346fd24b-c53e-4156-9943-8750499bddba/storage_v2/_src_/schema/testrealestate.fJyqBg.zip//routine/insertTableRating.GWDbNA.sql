create
    definer = root@localhost procedure insertTableRating(IN userrate_ int, IN ratingscore_ int, IN idinsert_ int, IN type_ int)
BEGIN
    declare id_ INT DEFAULT 0;
    insert into rating(id,ratingscore,userrate,type) values(idinsert_,ratingscore_,userrate_,type_);
    insert into ratingestate(id) values (idinsert_);
END;

