create
    definer = root@localhost procedure insertTableUserRating(IN userrate_ int, IN ratingscore_ int, IN idinsert_ int,
                                                             IN type_ int, IN comment_ varchar(50))
BEGIN
    declare id_ INT DEFAULT 0;
    declare date_ date DEFAULT  CURRENT_DATE();
    insert into rating(idrating,ratingscore,userrate,type,daterating) values(idinsert_,ratingscore_,userrate_,type_,date_);
    select id_=id from rating where idrating=idinsert_ and ratingscore = ratingscore_ and userrate=userrate_ and type=type_;
    insert into ratinguser(id,userid,comment) values (id_,idinsert_,comment_);
END;

