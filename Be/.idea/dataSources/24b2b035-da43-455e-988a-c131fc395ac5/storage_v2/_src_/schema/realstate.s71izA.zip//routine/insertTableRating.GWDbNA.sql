create
    definer = root@localhost procedure insertTableRating(IN idinsert_ int, IN ratingscore_ int, IN userrate_ int, IN type_ int)
BEGIN
    declare id_ INT DEFAULT 0;
    declare date_ date DEFAULT  CURRENT_DATE();
    insert into rating(idrating,ratingscore,userrate,type,daterating) values(idinsert_,ratingscore_,userrate_,type_,date_);
    select id_=id from rating where idrating=idinsert_ and ratingscore = ratingscore_ and userrate=userrate_ and type=type_
                                and daterating=date_;
    insert into ratingestate(id,estateid) values (id_,idinsert_);
END;

