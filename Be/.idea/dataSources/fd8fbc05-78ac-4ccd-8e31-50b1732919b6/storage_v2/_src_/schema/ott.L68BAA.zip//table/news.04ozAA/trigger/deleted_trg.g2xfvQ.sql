create definer = ott_vasc@`%` trigger deleted_trg
    before delete
    on news
    for each row
    INSERT INTO NEWS_DELETE(deleted_id, deleted_at)
	VALUES (old.NEWS_ID, now());

