create view SEARCH_VIEW as
select `ott`.`NET_MOVIE`.`MOVIE_ID`           AS `OBJECT_ID`,
       `ott`.`NET_MOVIE`.`MOVIE_NAME`         AS `OBJECT_NAME`,
       `ott`.`NET_MOVIE`.`MOVIE_KEYWORD`      AS `OBJECT_KEYWORD`,
       2                                      AS `OBJECT_TYPE`,
       `ott`.`NET_MOVIE`.`HIDDEN_DEVICE_LIST` AS `HIDDEN_DEVICE_LIST`,
       `ott`.`NET_MOVIE`.`BUSINESS_TYPE`      AS `BUSINESS_TYPE`,
       `ott`.`NET_MOVIE`.`MOVIE_VER_POSTER`   AS `OBJECT_VER_POSTER`,
       `ott`.`NET_MOVIE`.`MOVIE_HOR_POSTER`   AS `OBJECT_HOR_POSTER`,
       `ott`.`NET_MOVIE`.`MODIFYDATE`         AS `MODIFYDATE`
from `ott`.`NET_MOVIE`
where (`ott`.`NET_MOVIE`.`MOVIE_STATUS` = 1)
union all
select `ott`.`NET_CONTENT`.`CONTENT_ID`         AS `OBJECT_ID`,
       `ott`.`NET_CONTENT`.`CONTENT_NAME`       AS `OBJECT_NAME`,
       `ott`.`NET_CONTENT`.`CONTENT_KEYWORD`    AS `OBJECT_KEYWORD`,
       3                                        AS `OBJECT_TYPE`,
       `ott`.`NET_CONTENT`.`HIDDEN_DEVICE_LIST` AS `HIDDEN_DEVICE_LIST`,
       `ott`.`NET_CONTENT`.`BUSINESS_TYPE`      AS `BUSINESS_TYPE`,
       `ott`.`NET_CONTENT`.`CONTENT_VER_POSTER` AS `OBJECT_VER_POSTER`,
       `ott`.`NET_CONTENT`.`CONTENT_HOR_POSTER` AS `OBJECT_HOR_POSTER`,
       `ott`.`NET_CONTENT`.`MODIFYDATE`         AS `MODIFYDATE`
from `ott`.`NET_CONTENT`
where (`ott`.`NET_CONTENT`.`CONTENT_STATUS` = 1);

