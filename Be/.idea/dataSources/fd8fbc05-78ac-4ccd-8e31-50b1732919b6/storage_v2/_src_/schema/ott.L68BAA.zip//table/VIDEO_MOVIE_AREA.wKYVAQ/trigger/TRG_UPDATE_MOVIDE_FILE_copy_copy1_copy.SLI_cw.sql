create definer = hiep@`192.168.1.45` trigger TRG_UPDATE_MOVIDE_FILE_copy_copy1_copy
    after insert
    on VIDEO_MOVIE_AREA
    for each row
BEGIN

UPDATE VIDEO_MOVIE_FILES set VIDEO_MOVIE_FILES .MOVIE_ID=  NEW.MOVIE_ID  where VIDEO_MOVIE_FILES .MOVIE_CODE = NEW.MOVIE_CODE;

END;

