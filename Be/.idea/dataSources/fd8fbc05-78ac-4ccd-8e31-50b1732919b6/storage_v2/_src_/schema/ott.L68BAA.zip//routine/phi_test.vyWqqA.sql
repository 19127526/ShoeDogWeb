create
    definer = ott@`172.16.%.%` procedure phi_test()
begin
	select 1;
end;

